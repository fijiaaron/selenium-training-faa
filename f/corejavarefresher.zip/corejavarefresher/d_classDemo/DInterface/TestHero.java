package corejavarefresher.d_classDemo.DInterface;


public class TestHero {

	public static void main(String[] args) {
	HeroBicycles myBike = new HeroBicycles();
	myBike.applyBrakes(30);
	}
	
}
