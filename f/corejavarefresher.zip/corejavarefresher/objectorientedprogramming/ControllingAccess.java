package corejavarefresher.objectorientedprogramming;

public class ControllingAccess {

	/*              (pac A) (P in A)  (Q not in A) (R not in A and not child)
	Modifier 		ClassZ 	Package 	Subclass 	World
	public 			Y 		Y 			Y 			Y           //k
	protected 		Y 		Y 			Y		 	N           //j
	no modifier 	Y 		Y 			N 			N           //l
	private 		Y 		N 			N 			N           //i
	 */
	
	
}



//protected class Protected {}
