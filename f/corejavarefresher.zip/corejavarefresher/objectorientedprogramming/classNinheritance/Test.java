package corejavarefresher.objectorientedprogramming.classNinheritance;

public class Test {

}
