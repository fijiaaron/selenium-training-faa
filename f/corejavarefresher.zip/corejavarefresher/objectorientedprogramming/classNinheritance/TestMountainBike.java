package corejavarefresher.objectorientedprogramming.classNinheritance;


public class TestMountainBike {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MountainBike mbike, mbike1;
		Bicycle bike1;
		bike1 = new Bicycle(2,3,5);		
		mbike = new MountainBike(4,5,6,7);
		mbike.setGear(30);
		mbike.setCadence(20);
		mbike1 = new MountainBike(4,5,6,7);
//		mbike1.seatHeight;
	//	mbike1.seatHeight;
		mbike.setCadence(20);
		mbike.setGear(20);
		mbike.setGear(1);
		//mbike.
		//mbike1 = new MountainBike();
	//	mbike.
		//mbike.doSome();
	//	mbike1.doSome();
	}

}
